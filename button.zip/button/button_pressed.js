


function mybutton_pressed(){
	alert("BUTTON PRESSED");
	
}
