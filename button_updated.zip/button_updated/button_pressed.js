


function mybutton_pressed(value){
	if(value == 'left')
		alert("left arrow clicked");
	else if(value == 'up')
		alert("up arrow clicked");
	else if(value == 'right')
		alert("right arrow clicked");
	else if(value == 'down')
		alert("down arrow clicked");
		
	
}
function mybutton(event){
	var key = event.keyCode;
	if(key == 37)
		alert("left arrow");
	else if (key == 38)
		alert("up arrow");
	else if (key == 39)
		alert("right arrow");
	else if (key == 40)
		alert("down arrow");

}
